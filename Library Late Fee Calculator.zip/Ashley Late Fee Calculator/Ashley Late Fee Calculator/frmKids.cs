﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ashley_Late_Fee_Calculator
{
    public partial class frmKids : Form
    {
        //variable Declaration
        double number_of_dates;
        double lateFee;
        double number_of_movies;
        double taxAmount;
        double totalAmount;

        public frmKids()
        {
            InitializeComponent();
            dtdueDate.MaxDate = DateTime.Today.AddDays(-1);
        }
       
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                if (isValidData())
                {
                    //Generate the current Date
                    DateTime currentDate = DateTime.Now;
                    //generate the due date base on user entry in textbox txtdueDate 
                    String dueDate = dtdueDate.Text;
                    DateTime inputDate = DateTime.Parse(dueDate);

                    //Display the  current date in textCurrent date 
                    txtCurrent.Text = currentDate.ToString(@"MM-dd-yyyy");
                    TimeSpan days = (currentDate.Date - inputDate);


                    number_of_dates = days.TotalDays;
                    //Display the number of days late in textbox txtdaysLate
                    txtdaysLate.Text = number_of_dates.ToString();

                    //call the calculate Late fees method and pass the number of days variable
                    lateFee = this.CalculateLateFee(number_of_dates);
                    //Display the lateFee in textbox txtLateFee
                    txtLateFee.Text = lateFee.ToString("c");

                    //Calculate the tax
                    taxAmount = lateFee * taxValue / 100;
                    txtTax.Text = taxAmount.ToString();

                    //Calculate the Total Tax
                    totalAmount = lateFee + taxAmount;
                    txtTotal.Text = totalAmount.ToString();
                }

            }
            catch (FormatException)
            {
                MessageBox.Show("FormateException Error");
            }
            catch (OverflowException)
            {
                MessageBox.Show("OverflowException Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n\n" + ex.GetType().ToString() + "\n" + ex.StackTrace, "Exception"); //it will show the error message
            }
        
        }

        //it is used  to remove the data when we click return back button
        private void btnReturn_Click(object sender, EventArgs e)
        {
            txtCurrent.Text = "";
            txtnumberOfMovies.Text = "";
            txtdaysLate.Text = "";
            txtLateFee.Text = "";
            txtmoviesTitle.Text = "";

            number_of_dates = 0;
            lateFee = 0;
            number_of_movies = 0;
            numberMovies = 0;
            title.Clear();
            Display.Enabled = false;
            taxValue = 13;
            lblTax.Text = "Tax(13%)";
            this.Hide();//Hide this form to reveal frmMain
        }

        //Create the new method for calculating the late fees and return the value
        private double CalculateLateFee(double number_of_days)
        {
            number_of_movies = Convert.ToDouble(txtnumberOfMovies.Text);
            lateFee = number_of_days * number_of_movies * 0.15;
            txtLateFee.Text = lateFee.ToString("c");
            return lateFee;

        }

        //Event for Clearing lateFees Text-field
        private void ClearLateFeeText(object sender, EventArgs e)
        {
            //it checks the condiation of text if its is empty or not
            txtLateFee.Text = ""; // it will clear the data of LateFees
            txtCurrent.Text = "";// it will clear the data of current date
            txtdaysLate.Text = "";// it will clear the data of number of days late

            txtTax.Text = "";//it will clear the data of taxAmount
            txtTotal.Text = "";//it will clear the data of TotalAmount
        }

        //Creating a list of string
        List<string> title = new List<string>();
        int numberMovies = 0;
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtmoviesTitle.Text == "")
                {
                    MessageBox.Show("Movie title Name can not be empty");
                }
                else {
                    //adding data from txtMoviestitle inti list
                    title.Add(txtmoviesTitle.Text);
                    numberMovies = numberMovies + 1;
                    //incrementing the count in each adding of moviesTitle
                    txtmoviesTitle.Text = numberMovies.ToString();
                    txtnumberOfMovies.Text = numberMovies.ToString();
                    txtmoviesTitle.Focus();
                    txtmoviesTitle.Text = "";
                    Display.Enabled = true;
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message + "\n\n" + ex.GetType().ToString() + "\n" + ex.StackTrace, "Exception"); //it will show the error message
            }

        }

        private void Display_Click(object sender, EventArgs e)
        {
            //sorting the added data from txtMovieTitle
            string outputTitle = "";
            title.Sort();
            foreach (string s in title)
            {
                outputTitle += s + "\n";
            }
            //Displaying all the movie title list in message box alphabetically
            MessageBox.Show(outputTitle,"Movie List");
            txtmoviesTitle.Focus();
        }

        //Checking validation for all methods
        private bool isValidData()
        {
            return
                IsPositive(txtnumberOfMovies, "Value");
        }


        //this method helps to check the value is positive or not
        public bool IsPositive(TextBox textbox, String name)
        {
            int number_of_movies = Convert.ToInt32(txtnumberOfMovies.Text);
            if (number_of_movies < 0)
            {
                MessageBox.Show(name + " must be a positive number.", "Positive Number Error");
                textbox.Focus();
                return false;
            }
            return true;
        }

        Double taxValue = 13;
        private void btnTax_Click(object sender, EventArgs e)
        {
            frmsaleTax frm = new frmsaleTax();
            frm.ShowDialog();
            String tax = (String)frm.Tag;
            if (tax != "")
            {
                taxValue = Convert.ToDouble(tax);
            }
            else
            {
                taxValue = 13;
            }
            lblTax.Text = "Tax(" + taxValue + "%)";
            txtLateFee.Text = ""; // it will clear the data of LateFees
            txtCurrent.Text = "";// it will clear the data of current date
            txtdaysLate.Text = "";// it will clear the data of number of days late

            txtTax.Text = "";//it will clear the data of taxAmount
            txtTotal.Text = "";//it will clear the data of TotalAmount

        }
    }
}
