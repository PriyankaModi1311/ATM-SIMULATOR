﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ashley_Late_Fee_Calculator
{
    public partial class frmNew : Form
    {
        public frmNew()
        {
            InitializeComponent();
            dtdueDate.MaxDate = DateTime.Today.AddDays(-1);
        }
        //variable Declaration
        double number_of_dates;
        double lateFee;
        double number_of_movies;
        double taxAmount;
        double totalAmount;
          

        //Create the new method for calculating the late fees and return the value
        private double CalculateLateFee(double number_of_days)
        {
            number_of_movies = Convert.ToDouble(txtnumberOfMovies.Text);
            lateFee = number_of_days * number_of_movies * 2;
            txtLateFee.Text = lateFee.ToString("c");
            return lateFee;
        }

        //Event for Clearing lateFees Text-field
        private void ClearLateFeeText(object sender, EventArgs e)
        {
            //it checks the condiation of text if its is empty or not
            txtLateFee.Text = ""; // it will clear the data of LateFees
            txtCurrent.Text = "";// it will clear the data of current date
            txtdaysLate.Text = "";// it will clear the data of number of days late

            txtTax.Text = "";//it will clear the data of taxAmount
            txtTotal.Text = "";//it will clear the data of TotalAmount
        }

        //Checking validation for all methods
        private bool isValidData()
        {
            return
                IsPositive(txtnumberOfMovies, "Value");
        }


        //this method helps to check the value is positive or not
        public bool IsPositive(TextBox textbox, String name)
        {
            int number_of_movies = Convert.ToInt32(txtnumberOfMovies.Text);
            if (number_of_movies < 0)
            {
                MessageBox.Show(name + " must be a positive number.", "Positive Number Error");
                textbox.Focus();
                return false;
            }
            return true;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                if (isValidData())
                {
                    //Generate the current Date
                    DateTime currentDate = DateTime.Now;
                    //generate the due date base on user entry in textbox txtdueDate 
                    String dueDate = dtdueDate.Text;
                    DateTime inputDate = DateTime.Parse(dueDate);

                    //Display the  current date in textCurrent date 
                    txtCurrent.Text = currentDate.ToString(@"MM-dd-yyyy");
                    TimeSpan days = (currentDate.Date - inputDate);


                    number_of_dates = days.TotalDays;
                    //Display the number of days late in textbox txtdaysLate
                    txtdaysLate.Text = number_of_dates.ToString();

                    //call the calculate Late fees method and pass the number of days variable
                    lateFee = this.CalculateLateFee(number_of_dates);
                    //Display the lateFee in textbox txtLateFee
                    txtLateFee.Text = lateFee.ToString("c");

                    //Calculate the tax
                    taxAmount = lateFee * taxValue / 100;
                    txtTax.Text = taxAmount.ToString();

                    //Calculate the Total Tax
                    totalAmount = lateFee + taxAmount;
                    txtTotal.Text = totalAmount.ToString();
                }

            }
            catch (FormatException)
            {
                MessageBox.Show("FormateException Error");
            }
            catch (OverflowException)
            {
                MessageBox.Show("OverflowException Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n\n" + ex.GetType().ToString()
                    + "\n" + ex.StackTrace, "Exception"); //it will show the error message
                txtCurrent.Text = "";
                txtdaysLate.Text = "";
            }
        }

        private void btnReturn_Click_1(object sender, EventArgs e)
        {
            //For Clear the Text-Field
            txtCurrent.Text = "";
            txtnumberOfMovies.Text = "";
            txtdaysLate.Text = "";
            txtLateFee.Text = "";

            number_of_dates = 0;
            lateFee = 0;
            number_of_movies = 0;
            taxValue = 13;
            lblTax.Text = "Tax(13%)";
            this.Hide();//Hide this form to reveal frmMain
        }

        Double taxValue = 13;
        private void btnTax_Click(object sender, EventArgs e)
        {
            frmsaleTax frm = new frmsaleTax();
            frm.ShowDialog();
            String tax = (String)frm.Tag;
            if (tax != "")
            {
                taxValue = Convert.ToDouble(tax);
            }
            else
            {
                taxValue = 13;
            }
            lblTax.Text = "Tax("+ taxValue + "%)";
            txtLateFee.Text = ""; // it will clear the data of LateFees
            txtCurrent.Text = "";// it will clear the data of current date
            txtdaysLate.Text = "";// it will clear the data of number of days late

            txtTax.Text = "";//it will clear the data of taxAmount
            txtTotal.Text = "";//it will clear the data of TotalAmount

        }
    }
}
