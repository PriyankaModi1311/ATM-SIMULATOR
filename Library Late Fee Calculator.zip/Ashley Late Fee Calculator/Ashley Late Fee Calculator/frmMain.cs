﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ashley_Late_Fee_Calculator
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
            txtCurrent.Text = DateTime.Now.ToString(@"MM-dd-yyyy");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        frmNew newRelease = new frmNew();
        private void btnNewReleases_Click(object sender, EventArgs e)
        {
            newRelease.ShowDialog();
        }
        frmLibrary libraryMovies = new frmLibrary();
        private void btnLibraryMovies_Click(object sender, EventArgs e)
        {
            libraryMovies.ShowDialog();

        }
        frmKids kidsMovies = new frmKids();
        private void btnKidsMovies_Click(object sender, EventArgs e)
        {

            kidsMovies.ShowDialog();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        private void txtCurrent_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
