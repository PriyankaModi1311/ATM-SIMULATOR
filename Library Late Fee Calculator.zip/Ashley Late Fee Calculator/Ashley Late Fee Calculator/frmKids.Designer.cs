﻿namespace Ashley_Late_Fee_Calculator
{
    partial class frmKids
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblKidsMovie = new System.Windows.Forms.Label();
            this.txtnumberOfMovies = new System.Windows.Forms.TextBox();
            this.lblnumberOfMovies = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.txtLateFee = new System.Windows.Forms.TextBox();
            this.txtdaysLate = new System.Windows.Forms.TextBox();
            this.txtCurrent = new System.Windows.Forms.TextBox();
            this.btnReturn = new System.Windows.Forms.Button();
            this.lblLateFee = new System.Windows.Forms.Label();
            this.lblNumberofDaysLate = new System.Windows.Forms.Label();
            this.lblcurrentDate = new System.Windows.Forms.Label();
            this.lbldueDate = new System.Windows.Forms.Label();
            this.lblmoviesTitle = new System.Windows.Forms.Label();
            this.txtmoviesTitle = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.Display = new System.Windows.Forms.Button();
            this.lblTax = new System.Windows.Forms.Label();
            this.txtTax = new System.Windows.Forms.TextBox();
            this.dtdueDate = new System.Windows.Forms.DateTimePicker();
            this.btnTax = new System.Windows.Forms.Button();
            this.lblTotal = new System.Windows.Forms.Label();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblKidsMovie
            // 
            this.lblKidsMovie.AutoSize = true;
            this.lblKidsMovie.BackColor = System.Drawing.Color.Transparent;
            this.lblKidsMovie.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKidsMovie.Location = new System.Drawing.Point(269, 9);
            this.lblKidsMovie.Name = "lblKidsMovie";
            this.lblKidsMovie.Size = new System.Drawing.Size(97, 21);
            this.lblKidsMovie.TabIndex = 21;
            this.lblKidsMovie.Text = "Kids Movie";
            // 
            // txtnumberOfMovies
            // 
            this.txtnumberOfMovies.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnumberOfMovies.Location = new System.Drawing.Point(181, 94);
            this.txtnumberOfMovies.Name = "txtnumberOfMovies";
            this.txtnumberOfMovies.Size = new System.Drawing.Size(157, 22);
            this.txtnumberOfMovies.TabIndex = 2;
            this.txtnumberOfMovies.TextChanged += new System.EventHandler(this.ClearLateFeeText);
            // 
            // lblnumberOfMovies
            // 
            this.lblnumberOfMovies.AutoSize = true;
            this.lblnumberOfMovies.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnumberOfMovies.Location = new System.Drawing.Point(26, 93);
            this.lblnumberOfMovies.Name = "lblnumberOfMovies";
            this.lblnumberOfMovies.Size = new System.Drawing.Size(109, 15);
            this.lblnumberOfMovies.TabIndex = 43;
            this.lblnumberOfMovies.Text = "Number Of Movies";
            // 
            // btnCalculate
            // 
            this.btnCalculate.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculate.Location = new System.Drawing.Point(32, 361);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(100, 28);
            this.btnCalculate.TabIndex = 3;
            this.btnCalculate.Text = "&Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // txtLateFee
            // 
            this.txtLateFee.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLateFee.Location = new System.Drawing.Point(180, 220);
            this.txtLateFee.Name = "txtLateFee";
            this.txtLateFee.ReadOnly = true;
            this.txtLateFee.Size = new System.Drawing.Size(157, 22);
            this.txtLateFee.TabIndex = 42;
            this.txtLateFee.TabStop = false;
            // 
            // txtdaysLate
            // 
            this.txtdaysLate.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdaysLate.Location = new System.Drawing.Point(180, 178);
            this.txtdaysLate.Name = "txtdaysLate";
            this.txtdaysLate.ReadOnly = true;
            this.txtdaysLate.Size = new System.Drawing.Size(157, 22);
            this.txtdaysLate.TabIndex = 40;
            this.txtdaysLate.TabStop = false;
            // 
            // txtCurrent
            // 
            this.txtCurrent.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCurrent.Location = new System.Drawing.Point(180, 136);
            this.txtCurrent.Name = "txtCurrent";
            this.txtCurrent.ReadOnly = true;
            this.txtCurrent.Size = new System.Drawing.Size(157, 22);
            this.txtCurrent.TabIndex = 37;
            this.txtCurrent.TabStop = false;
            // 
            // btnReturn
            // 
            this.btnReturn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnReturn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnReturn.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.Location = new System.Drawing.Point(532, 361);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 28);
            this.btnReturn.TabIndex = 8;
            this.btnReturn.Text = "&Return";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // lblLateFee
            // 
            this.lblLateFee.AutoSize = true;
            this.lblLateFee.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLateFee.Location = new System.Drawing.Point(26, 219);
            this.lblLateFee.Name = "lblLateFee";
            this.lblLateFee.Size = new System.Drawing.Size(52, 15);
            this.lblLateFee.TabIndex = 41;
            this.lblLateFee.Text = "Late Fee";
            // 
            // lblNumberofDaysLate
            // 
            this.lblNumberofDaysLate.AutoSize = true;
            this.lblNumberofDaysLate.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumberofDaysLate.Location = new System.Drawing.Point(26, 177);
            this.lblNumberofDaysLate.Name = "lblNumberofDaysLate";
            this.lblNumberofDaysLate.Size = new System.Drawing.Size(122, 15);
            this.lblNumberofDaysLate.TabIndex = 39;
            this.lblNumberofDaysLate.Text = "Number Of Days Late";
            // 
            // lblcurrentDate
            // 
            this.lblcurrentDate.AutoSize = true;
            this.lblcurrentDate.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcurrentDate.Location = new System.Drawing.Point(26, 135);
            this.lblcurrentDate.Name = "lblcurrentDate";
            this.lblcurrentDate.Size = new System.Drawing.Size(75, 15);
            this.lblcurrentDate.TabIndex = 36;
            this.lblcurrentDate.Text = "Current Date";
            // 
            // lbldueDate
            // 
            this.lbldueDate.AutoSize = true;
            this.lbldueDate.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldueDate.Location = new System.Drawing.Point(26, 51);
            this.lbldueDate.Name = "lbldueDate";
            this.lbldueDate.Size = new System.Drawing.Size(57, 15);
            this.lbldueDate.TabIndex = 33;
            this.lbldueDate.Text = "Due Date";
            // 
            // lblmoviesTitle
            // 
            this.lblmoviesTitle.AutoSize = true;
            this.lblmoviesTitle.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmoviesTitle.Location = new System.Drawing.Point(376, 51);
            this.lblmoviesTitle.Name = "lblmoviesTitle";
            this.lblmoviesTitle.Size = new System.Drawing.Size(70, 15);
            this.lblmoviesTitle.TabIndex = 44;
            this.lblmoviesTitle.Text = "Movies Title";
            // 
            // txtmoviesTitle
            // 
            this.txtmoviesTitle.Location = new System.Drawing.Point(475, 52);
            this.txtmoviesTitle.Name = "txtmoviesTitle";
            this.txtmoviesTitle.Size = new System.Drawing.Size(157, 20);
            this.txtmoviesTitle.TabIndex = 5;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(407, 361);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 28);
            this.btnAdd.TabIndex = 6;
            this.btnAdd.Text = "&Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // Display
            // 
            this.Display.Enabled = false;
            this.Display.Location = new System.Drawing.Point(282, 361);
            this.Display.Name = "Display";
            this.Display.Size = new System.Drawing.Size(100, 28);
            this.Display.TabIndex = 7;
            this.Display.Text = "&Display";
            this.Display.UseVisualStyleBackColor = true;
            this.Display.Click += new System.EventHandler(this.Display_Click);
            // 
            // lblTax
            // 
            this.lblTax.AutoSize = true;
            this.lblTax.Font = new System.Drawing.Font("Times New Roman", 9.75F);
            this.lblTax.Location = new System.Drawing.Point(26, 261);
            this.lblTax.Name = "lblTax";
            this.lblTax.Size = new System.Drawing.Size(59, 15);
            this.lblTax.TabIndex = 48;
            this.lblTax.Text = "Tax(13%):";
            // 
            // txtTax
            // 
            this.txtTax.Location = new System.Drawing.Point(180, 262);
            this.txtTax.Name = "txtTax";
            this.txtTax.ReadOnly = true;
            this.txtTax.Size = new System.Drawing.Size(157, 20);
            this.txtTax.TabIndex = 49;
            this.txtTax.TabStop = false;
            // 
            // dtdueDate
            // 
            this.dtdueDate.CustomFormat = "MM-dd-yyyy";
            this.dtdueDate.Font = new System.Drawing.Font("Times New Roman", 9.75F);
            this.dtdueDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtdueDate.Location = new System.Drawing.Point(181, 52);
            this.dtdueDate.MaxDate = new System.DateTime(2049, 12, 10, 0, 0, 0, 0);
            this.dtdueDate.MinDate = new System.DateTime(1991, 12, 10, 0, 0, 0, 0);
            this.dtdueDate.Name = "dtdueDate";
            this.dtdueDate.Size = new System.Drawing.Size(157, 22);
            this.dtdueDate.TabIndex = 1;
            this.dtdueDate.Value = new System.DateTime(2018, 4, 5, 7, 53, 0, 0);
            // 
            // btnTax
            // 
            this.btnTax.Location = new System.Drawing.Point(157, 361);
            this.btnTax.Name = "btnTax";
            this.btnTax.Size = new System.Drawing.Size(100, 28);
            this.btnTax.TabIndex = 4;
            this.btnTax.Text = "&Tax Percent";
            this.btnTax.UseVisualStyleBackColor = true;
            this.btnTax.Click += new System.EventHandler(this.btnTax_Click);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(26, 303);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(34, 13);
            this.lblTotal.TabIndex = 50;
            this.lblTotal.Text = "Total:";
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(180, 302);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.ReadOnly = true;
            this.txtTotal.Size = new System.Drawing.Size(157, 20);
            this.txtTotal.TabIndex = 51;
            this.txtTotal.TabStop = false;
            // 
            // frmKids
            // 
            this.AcceptButton = this.btnCalculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.CancelButton = this.btnReturn;
            this.ClientSize = new System.Drawing.Size(667, 401);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.btnTax);
            this.Controls.Add(this.dtdueDate);
            this.Controls.Add(this.txtTax);
            this.Controls.Add(this.lblTax);
            this.Controls.Add(this.Display);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtmoviesTitle);
            this.Controls.Add(this.lblmoviesTitle);
            this.Controls.Add(this.txtnumberOfMovies);
            this.Controls.Add(this.lblnumberOfMovies);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.txtLateFee);
            this.Controls.Add(this.txtdaysLate);
            this.Controls.Add(this.txtCurrent);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.lblLateFee);
            this.Controls.Add(this.lblNumberofDaysLate);
            this.Controls.Add(this.lblcurrentDate);
            this.Controls.Add(this.lbldueDate);
            this.Controls.Add(this.lblKidsMovie);
            this.Name = "frmKids";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmKids";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblKidsMovie;
        private System.Windows.Forms.TextBox txtnumberOfMovies;
        private System.Windows.Forms.Label lblnumberOfMovies;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.TextBox txtLateFee;
        private System.Windows.Forms.TextBox txtdaysLate;
        private System.Windows.Forms.TextBox txtCurrent;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Label lblLateFee;
        private System.Windows.Forms.Label lblNumberofDaysLate;
        private System.Windows.Forms.Label lblcurrentDate;
        private System.Windows.Forms.Label lbldueDate;
        private System.Windows.Forms.Label lblmoviesTitle;
        private System.Windows.Forms.TextBox txtmoviesTitle;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button Display;
        private System.Windows.Forms.Label lblTax;
        private System.Windows.Forms.TextBox txtTax;
        private System.Windows.Forms.DateTimePicker dtdueDate;
        private System.Windows.Forms.Button btnTax;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.TextBox txtTotal;
    }
}