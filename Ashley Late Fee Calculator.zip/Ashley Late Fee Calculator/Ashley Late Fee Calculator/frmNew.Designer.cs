﻿namespace Ashley_Late_Fee_Calculator
{
    partial class frmNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbldueDate = new System.Windows.Forms.Label();
            this.lblcurrentDate = new System.Windows.Forms.Label();
            this.lblNumberofDaysLate = new System.Windows.Forms.Label();
            this.lblLateFee = new System.Windows.Forms.Label();
            this.txtCurrent = new System.Windows.Forms.TextBox();
            this.txtdaysLate = new System.Windows.Forms.TextBox();
            this.txtLateFee = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblnumberOfMovies = new System.Windows.Forms.Label();
            this.txtnumberOfMovies = new System.Windows.Forms.TextBox();
            this.dtdueDate = new System.Windows.Forms.DateTimePicker();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.txtTax = new System.Windows.Forms.TextBox();
            this.lblTax = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnTax = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbldueDate
            // 
            this.lbldueDate.AutoSize = true;
            this.lbldueDate.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldueDate.Location = new System.Drawing.Point(40, 54);
            this.lbldueDate.Name = "lbldueDate";
            this.lbldueDate.Size = new System.Drawing.Size(57, 15);
            this.lbldueDate.TabIndex = 0;
            this.lbldueDate.Text = "Due Date";
            // 
            // lblcurrentDate
            // 
            this.lblcurrentDate.AutoSize = true;
            this.lblcurrentDate.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcurrentDate.Location = new System.Drawing.Point(40, 140);
            this.lblcurrentDate.Name = "lblcurrentDate";
            this.lblcurrentDate.Size = new System.Drawing.Size(75, 15);
            this.lblcurrentDate.TabIndex = 2;
            this.lblcurrentDate.Text = "Current Date";
            // 
            // lblNumberofDaysLate
            // 
            this.lblNumberofDaysLate.AutoSize = true;
            this.lblNumberofDaysLate.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumberofDaysLate.Location = new System.Drawing.Point(40, 183);
            this.lblNumberofDaysLate.Name = "lblNumberofDaysLate";
            this.lblNumberofDaysLate.Size = new System.Drawing.Size(122, 15);
            this.lblNumberofDaysLate.TabIndex = 4;
            this.lblNumberofDaysLate.Text = "Number Of Days Late";
            // 
            // lblLateFee
            // 
            this.lblLateFee.AutoSize = true;
            this.lblLateFee.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLateFee.Location = new System.Drawing.Point(40, 226);
            this.lblLateFee.Name = "lblLateFee";
            this.lblLateFee.Size = new System.Drawing.Size(52, 15);
            this.lblLateFee.TabIndex = 6;
            this.lblLateFee.Text = "Late Fee";
            // 
            // txtCurrent
            // 
            this.txtCurrent.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCurrent.Location = new System.Drawing.Point(188, 138);
            this.txtCurrent.Name = "txtCurrent";
            this.txtCurrent.ReadOnly = true;
            this.txtCurrent.Size = new System.Drawing.Size(157, 22);
            this.txtCurrent.TabIndex = 3;
            this.txtCurrent.TabStop = false;
            // 
            // txtdaysLate
            // 
            this.txtdaysLate.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdaysLate.Location = new System.Drawing.Point(188, 180);
            this.txtdaysLate.Name = "txtdaysLate";
            this.txtdaysLate.ReadOnly = true;
            this.txtdaysLate.Size = new System.Drawing.Size(157, 22);
            this.txtdaysLate.TabIndex = 5;
            this.txtdaysLate.TabStop = false;
            // 
            // txtLateFee
            // 
            this.txtLateFee.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLateFee.Location = new System.Drawing.Point(188, 222);
            this.txtLateFee.Name = "txtLateFee";
            this.txtLateFee.ReadOnly = true;
            this.txtLateFee.Size = new System.Drawing.Size(157, 22);
            this.txtLateFee.TabIndex = 7;
            this.txtLateFee.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(131, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 21);
            this.label1.TabIndex = 11;
            this.label1.Text = "New Release";
            // 
            // lblnumberOfMovies
            // 
            this.lblnumberOfMovies.AutoSize = true;
            this.lblnumberOfMovies.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnumberOfMovies.Location = new System.Drawing.Point(40, 97);
            this.lblnumberOfMovies.Name = "lblnumberOfMovies";
            this.lblnumberOfMovies.Size = new System.Drawing.Size(109, 15);
            this.lblnumberOfMovies.TabIndex = 12;
            this.lblnumberOfMovies.Text = "Number Of Movies";
            // 
            // txtnumberOfMovies
            // 
            this.txtnumberOfMovies.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnumberOfMovies.Location = new System.Drawing.Point(189, 96);
            this.txtnumberOfMovies.Name = "txtnumberOfMovies";
            this.txtnumberOfMovies.Size = new System.Drawing.Size(157, 22);
            this.txtnumberOfMovies.TabIndex = 2;
            this.txtnumberOfMovies.TextChanged += new System.EventHandler(this.ClearLateFeeText);
            // 
            // dtdueDate
            // 
            this.dtdueDate.CustomFormat = "MM-dd-yyyy";
            this.dtdueDate.Font = new System.Drawing.Font("Times New Roman", 9.75F);
            this.dtdueDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtdueDate.Location = new System.Drawing.Point(189, 54);
            this.dtdueDate.MaxDate = new System.DateTime(2049, 12, 31, 0, 0, 0, 0);
            this.dtdueDate.MinDate = new System.DateTime(1991, 12, 10, 0, 0, 0, 0);
            this.dtdueDate.Name = "dtdueDate";
            this.dtdueDate.Size = new System.Drawing.Size(157, 22);
            this.dtdueDate.TabIndex = 1;
            this.dtdueDate.Value = new System.DateTime(2018, 4, 5, 7, 53, 0, 0);
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(188, 304);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.ReadOnly = true;
            this.txtTotal.Size = new System.Drawing.Size(157, 20);
            this.txtTotal.TabIndex = 55;
            this.txtTotal.TabStop = false;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(40, 312);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(34, 13);
            this.lblTotal.TabIndex = 54;
            this.lblTotal.Text = "Total:";
            // 
            // txtTax
            // 
            this.txtTax.Location = new System.Drawing.Point(188, 264);
            this.txtTax.Name = "txtTax";
            this.txtTax.ReadOnly = true;
            this.txtTax.Size = new System.Drawing.Size(157, 20);
            this.txtTax.TabIndex = 53;
            this.txtTax.TabStop = false;
            // 
            // lblTax
            // 
            this.lblTax.AutoSize = true;
            this.lblTax.Font = new System.Drawing.Font("Times New Roman", 9.75F);
            this.lblTax.Location = new System.Drawing.Point(40, 269);
            this.lblTax.Name = "lblTax";
            this.lblTax.Size = new System.Drawing.Size(59, 15);
            this.lblTax.TabIndex = 52;
            this.lblTax.Text = "Tax(13%):";
            // 
            // btnCalculate
            // 
            this.btnCalculate.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculate.Location = new System.Drawing.Point(12, 361);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(100, 28);
            this.btnCalculate.TabIndex = 3;
            this.btnCalculate.Text = "&Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnTax
            // 
            this.btnTax.Location = new System.Drawing.Point(148, 361);
            this.btnTax.Name = "btnTax";
            this.btnTax.Size = new System.Drawing.Size(100, 28);
            this.btnTax.TabIndex = 4;
            this.btnTax.Text = "&Tax Percent";
            this.btnTax.UseVisualStyleBackColor = true;
            this.btnTax.Click += new System.EventHandler(this.btnTax_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnReturn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnReturn.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturn.Location = new System.Drawing.Point(284, 361);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 28);
            this.btnReturn.TabIndex = 5;
            this.btnReturn.Text = "&Return";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click_1);
            // 
            // frmNew
            // 
            this.AcceptButton = this.btnCalculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.CancelButton = this.btnReturn;
            this.ClientSize = new System.Drawing.Size(390, 401);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnTax);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.txtTax);
            this.Controls.Add(this.lblTax);
            this.Controls.Add(this.dtdueDate);
            this.Controls.Add(this.txtnumberOfMovies);
            this.Controls.Add(this.lblnumberOfMovies);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtLateFee);
            this.Controls.Add(this.txtdaysLate);
            this.Controls.Add(this.txtCurrent);
            this.Controls.Add(this.lblLateFee);
            this.Controls.Add(this.lblNumberofDaysLate);
            this.Controls.Add(this.lblcurrentDate);
            this.Controls.Add(this.lbldueDate);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmNew";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmNew";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbldueDate;
        private System.Windows.Forms.Label lblcurrentDate;
        private System.Windows.Forms.Label lblNumberofDaysLate;
        private System.Windows.Forms.Label lblLateFee;
        private System.Windows.Forms.TextBox txtCurrent;
        private System.Windows.Forms.TextBox txtdaysLate;
        private System.Windows.Forms.TextBox txtLateFee;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblnumberOfMovies;
        private System.Windows.Forms.TextBox txtnumberOfMovies;
        private System.Windows.Forms.DateTimePicker dtdueDate;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.TextBox txtTax;
        private System.Windows.Forms.Label lblTax;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnTax;
        private System.Windows.Forms.Button btnReturn;
    }
}