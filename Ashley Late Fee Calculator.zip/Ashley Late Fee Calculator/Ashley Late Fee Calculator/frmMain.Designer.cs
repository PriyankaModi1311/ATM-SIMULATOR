﻿namespace Ashley_Late_Fee_Calculator
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNewReleases = new System.Windows.Forms.Button();
            this.btnLibraryMovies = new System.Windows.Forms.Button();
            this.btnKidsMovies = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblAshLateFeeCal = new System.Windows.Forms.Label();
            this.txtCurrent = new System.Windows.Forms.TextBox();
            this.btnAddRemoveMovies = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnNewReleases
            // 
            this.btnNewReleases.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnNewReleases.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewReleases.Location = new System.Drawing.Point(14, 55);
            this.btnNewReleases.Name = "btnNewReleases";
            this.btnNewReleases.Size = new System.Drawing.Size(145, 33);
            this.btnNewReleases.TabIndex = 0;
            this.btnNewReleases.Text = "&New Releases";
            this.btnNewReleases.UseVisualStyleBackColor = false;
            this.btnNewReleases.Click += new System.EventHandler(this.btnNewReleases_Click);
            // 
            // btnLibraryMovies
            // 
            this.btnLibraryMovies.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnLibraryMovies.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLibraryMovies.Location = new System.Drawing.Point(14, 121);
            this.btnLibraryMovies.Name = "btnLibraryMovies";
            this.btnLibraryMovies.Size = new System.Drawing.Size(145, 33);
            this.btnLibraryMovies.TabIndex = 1;
            this.btnLibraryMovies.Text = "&Library Movies";
            this.btnLibraryMovies.UseVisualStyleBackColor = false;
            this.btnLibraryMovies.Click += new System.EventHandler(this.btnLibraryMovies_Click);
            // 
            // btnKidsMovies
            // 
            this.btnKidsMovies.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnKidsMovies.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKidsMovies.Location = new System.Drawing.Point(14, 182);
            this.btnKidsMovies.Name = "btnKidsMovies";
            this.btnKidsMovies.Size = new System.Drawing.Size(145, 33);
            this.btnKidsMovies.TabIndex = 2;
            this.btnKidsMovies.Text = "&Kids Movies";
            this.btnKidsMovies.UseVisualStyleBackColor = false;
            this.btnKidsMovies.Click += new System.EventHandler(this.btnKidsMovies_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.Black;
            this.btnExit.Location = new System.Drawing.Point(249, 257);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(109, 35);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblAshLateFeeCal
            // 
            this.lblAshLateFeeCal.AutoSize = true;
            this.lblAshLateFeeCal.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lblAshLateFeeCal.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAshLateFeeCal.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lblAshLateFeeCal.Location = new System.Drawing.Point(80, 20);
            this.lblAshLateFeeCal.Name = "lblAshLateFeeCal";
            this.lblAshLateFeeCal.Size = new System.Drawing.Size(159, 15);
            this.lblAshLateFeeCal.TabIndex = 25;
            this.lblAshLateFeeCal.Text = "Ashley\'s Late Fee Calculator";
            // 
            // txtCurrent
            // 
            this.txtCurrent.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtCurrent.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCurrent.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCurrent.Location = new System.Drawing.Point(282, 7);
            this.txtCurrent.Name = "txtCurrent";
            this.txtCurrent.Size = new System.Drawing.Size(76, 15);
            this.txtCurrent.TabIndex = 5;
            this.txtCurrent.TextChanged += new System.EventHandler(this.txtCurrent_TextChanged);
            // 
            // btnAddRemoveMovies
            // 
            this.btnAddRemoveMovies.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnAddRemoveMovies.Location = new System.Drawing.Point(14, 247);
            this.btnAddRemoveMovies.Name = "btnAddRemoveMovies";
            this.btnAddRemoveMovies.Size = new System.Drawing.Size(145, 33);
            this.btnAddRemoveMovies.TabIndex = 26;
            this.btnAddRemoveMovies.TabStop = false;
            this.btnAddRemoveMovies.Text = "&Add or Remove";
            this.btnAddRemoveMovies.UseVisualStyleBackColor = true;
            this.btnAddRemoveMovies.Click += new System.EventHandler(this.btnAddRemoveMovies_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(366, 302);
            this.Controls.Add(this.btnAddRemoveMovies);
            this.Controls.Add(this.txtCurrent);
            this.Controls.Add(this.lblAshLateFeeCal);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnKidsMovies);
            this.Controls.Add(this.btnLibraryMovies);
            this.Controls.Add(this.btnNewReleases);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmMain";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNewReleases;
        private System.Windows.Forms.Button btnLibraryMovies;
        private System.Windows.Forms.Button btnKidsMovies;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblAshLateFeeCal;
        private System.Windows.Forms.TextBox txtCurrent;
        private System.Windows.Forms.Button btnAddRemoveMovies;
    }
}

