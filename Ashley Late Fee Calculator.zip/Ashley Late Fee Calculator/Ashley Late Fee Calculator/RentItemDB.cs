﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Ashley_Late_Fee_Calculator
{
    public static class RentItemDB
    {
        private const string dir = @"C:\C# 2015\Files\";
        private const string path = dir + "RentalItem.txt";

        public static void SaveRentalItems(List<RentItem> rentItems)
        {
            StreamWriter textOut =
                new StreamWriter(
                new FileStream(path, FileMode.Create, FileAccess.Write));

            // write each customer
            foreach (RentItem rentItem in rentItems)
            {
                textOut.Write(rentItem.MovieNo + "|");
                textOut.Write(rentItem.Description + "|");
                textOut.WriteLine(rentItem.Rate);
            }

            // write the end of the document
            textOut.Close();
        }

        public static List<RentItem> GetRentItems()
        {
            // if the directory doesn't exist, create it
            if (!Directory.Exists(dir))
                Directory.CreateDirectory(dir);

            // create the object for the input stream for a text file
            StreamReader textIn =
                new StreamReader(
                    new FileStream(path, FileMode.OpenOrCreate, FileAccess.Read));

            // create the array list for customers
            List<RentItem> rentItems = new List<RentItem>();

            // read the data from the file and store it in the ArrayList
            while (textIn.Peek() != -1)
            {
                string row = textIn.ReadLine();
                string[] columns = row.Split('|');
                RentItem rentItem = new RentItem();
                rentItem.MovieNo = Convert.ToInt32(columns[0]);
                rentItem.Description = columns[1];
                rentItem.Rate = columns[2];
                rentItems.Add(rentItem);
            }

            textIn.Close();

            return rentItems;
        }
    }
}

