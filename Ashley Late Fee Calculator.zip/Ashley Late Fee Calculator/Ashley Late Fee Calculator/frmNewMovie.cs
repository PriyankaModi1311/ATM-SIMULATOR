﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace Ashley_Late_Fee_Calculator
{
    public partial class frmNewMovie : Form
    {
        public frmNewMovie()
        {
            InitializeComponent();
        }

        //Class Variable is null
        private RentItem rentItem = null;

        public RentItem GetNewRentItem()
        {
            this.ShowDialog();
            return rentItem;
        }
        

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (isValidData())
            {
                //assign the value from textbox to the object of the class RentItem
                rentItem = new RentItem(Convert.ToInt32(txtMovieNo.Text), txtDescription.Text, txtRate.Text);
                this.Close();
            }
        }
        private bool isValidData()
        {
            //Calling of the method IsPresent and IsInt32 from class validator
            return Validation.IsPresent(txtMovieNo)&&
                   Validation.IsInt32(txtMovieNo) &&
                Validation.IsPresent(txtDescription) &&
                Validation.IsPresent(txtRate);
          }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmNewMovie_Load(object sender, EventArgs e)
        {

        }
    }
}
