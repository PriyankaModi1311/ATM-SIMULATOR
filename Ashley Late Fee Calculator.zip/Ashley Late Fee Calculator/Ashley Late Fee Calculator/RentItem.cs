﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ashley_Late_Fee_Calculator
{
    public class RentItem
    {
        private int movieNo;
        private string description;
        private string rate;

        public RentItem() { }

        public RentItem(int movieNo, string description, string rate)
        {
            this.MovieNo = movieNo;
            this.Description = description;
            this.Rate = rate;
        }
        //set and get the all declare variables
        public int MovieNo
        {
            get
            {
                return movieNo;
            }
            set
            {
                movieNo = value;
            }
        }

        public string Description
        {
            get
            {
                return description;
            }
            set
            {
                description = value;
            }
        }

        public string Rate  
        {
            get
            {
                return rate;
            }
            set
            {
                rate = value;
            }
        }

        public string GetDisplayText() => movieNo + " " + description + ", " + rate;
    }
}

